This repository provide samples for GY-80 sensor which is composed of :
- adxl345 (accelerometer)
- BMP085 (pressure & temperature)
- HMC5883 (magnetometer)
- L3G4200D (Gyro)

Feel free to upgrade sample or provide enhanced informations