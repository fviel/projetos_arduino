Put L3G4200D directory containing .h and .cpp file in your library directory
see: http://arduino.cc/en/Guide/Libraries

Restart Arduino IDE, make sure the new library appears in the Sketch->Import Library menu item 
Load L3G4200D.ino sketch sample and enjoy !

